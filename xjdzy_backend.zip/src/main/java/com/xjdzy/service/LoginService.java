package com.xjdzy.service;

import com.xjdzy.entity.UserInfo;

public interface LoginService {

    UserInfo loginJudge(UserInfo userInfo);
}
