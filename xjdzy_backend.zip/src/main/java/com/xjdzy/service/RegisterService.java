package com.xjdzy.service;

import com.xjdzy.entity.UserInfo;

public interface RegisterService {

    String register(UserInfo userInfo);
}
